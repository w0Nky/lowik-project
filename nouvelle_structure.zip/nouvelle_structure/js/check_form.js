
function sure(){
	return confirm("T'es sur ??");
}
