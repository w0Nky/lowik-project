function previousSlide(){
	var children=$('#myCarousel').children();

	console.log(children);

}

function nextSlide(){
	
}