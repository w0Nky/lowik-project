<!-- PARTIE GESTION DE L'ACCUEIL -->
<!--  sliders -->
<div class="container bg-2 margin-top padding-top">
	<form class="form-horizontal" method="post" action="">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">Partie slider :</div>
				<div class="panel-body" style="color:black;">
					<div class="controls">
						<div class="entry input-group col-sm-12">
							<div class="form-group">
								<input class="btn btn-default" name="slide1" type="file">
								<input type="text" class="form-control" id="urlSlide1" name="urlSlide1" placeholder="Url slide 1" required>
							</div>
							<div class="form-group">
								<input class="btn btn-default" name="slide2" type="file">
								<input type="text" class="form-control" id="urlSlide2" name="urlSlide2" placeholder="Url slide 2" required>
							</div>
							<div class="form-group">
								<input class="btn btn-default" name="slide3" type="file">
								<input type="text" class="form-control" id="urlSlide3" name="urlSlide3" placeholder="Url slide 3" required>
							</div>
							<div class="form-group">
								<input class="btn btn-default" name="slide4" type="file">
								<input type="text" class="form-control" id="urlSlide4" name="urlSlide4" placeholder="Url slide 4" required>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>