<!-- PARTIE GESTION DE L'ACCUEIL -->
<!--  sliders -->
<div class="container bg-2 padding-top">
		<div class="col-sm-12">
			<div class="panel panel-default padding-bottom">
				<div class="panel-heading">Partie slider :</div>
				<div class="panel-body" style="color:black;">
					<form class="form-horizontal" method="post" action="">
						<div class="row">
				                <ul class="hide-bullets" style="list-style:none;">
				                <?php
				                	if(isset($liste_slider) && !empty($liste_slider)){
						                foreach ($liste_slider as $slider) { 
						        ?>
						                	<li class="col-sm-3">
						                		<label class="btn btn-primary">
						                            <img src="<?php echo ADRESSE_ABSOLUE_URL . $slider->path . $slider->nom;?>" class="img-thumbnail img-check <?php if($slider->actif) echo 'check'; ?>">
						                            <input type="checkbox" name="choix[]" value="<?php echo $slider->id; ?>" class="hidden" autocomplete="off" <?php if($slider->actif) echo 'checked'; ?>/>
												</label>
						                    </li>   
				               <?php 
				           				}//fin foreach
				           			}else{
				           				echo '<li class="col-sm-3"> Aucun slider</li>';
				           			}
		           				?> 
				                </ul>
		            	</div>
		            	<div class="row margin-top">
		            		<div class="row col-sm-offset-5">
            			   		<input type="submit" class="btn btn btn-success" name="valider" value="Valider">
            			   	</div>
		            	</div>
	            	</form>
					</div>
					<span style="clear:both"></span>
					<div class="row col-sm-offset-5">
						<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
							<div class="form-group">
								<p class="color-black"> Upload une image pour slider 
									<input class="btn btn-default input-sm" name="file" type="file">
								</p>
							</div>
							<input type="submit" class="btn btn btn-success" name="upload" value="upload">
						</form>
					</div>
				</div>
			</div>
		</div>
</div>