<!-- PARTIE GESTION DU COMPTe -->
<div class="container bg-2 margin-top padding-top">
	<form class="form-horizontal" method="post" action="">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">COMPTE ADMINISTRATEUR</div>
				<div class="panel-body" style="color:black;">
					<div class="form-area">  
							<span style="clear:both"></span>
								<p>Login</p>
								<input type="text" class="form-control" id="login" name="login" placeholder="Login" value="<?php echo $p_adminInfo->login; ?>" required>
								<p>Email</p>
								<input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo $p_adminInfo->email; ?>" required>
								<p>Password</p>
								<input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
								<p>Confirmation du password</p>
								<input type="password" class="form-control" id="passwordConfirmation" name="passwordConfirmation" placeholder="Password confirmation" required>
								
					</div>
					<div class="form-group">
						<div class="col-sm-offset-6">
						  <input type="submit" class="btn btn btn-success">
						</div>
					</div>
					<?php 
							if($modifOk){

								echo '<div class="alert alert-success alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[13].'
									</div>';
							}
							if($mdpKO){
								echo '<div class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[15].'
									</div>';
							}
							if($champVide){
								echo '<div class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[5].'
									</div>';
							}
							if($mdpTropCourt){
								echo '<div class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[23].'
									</div>';
							}
					?>	
				</div>
			</div>
		</div>
	</form>
</div>