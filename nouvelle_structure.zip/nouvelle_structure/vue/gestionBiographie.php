<!-- PARTIE GESTION DE LA BIOGRAPHIE -->
<div class="container bg-2 padding-top">
	<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">PARTIE BIOGRAPHIE</div>
				<div class="panel-body" style="color:black;">
					<?php
						if($codeRetour != -1){
							echo $code_retour[$codeRetour];
						}
					
						if($bienModifier){

							echo '<div class="alert alert-success alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong>Information : </strong>'.$code_retour[13].'
								</div>';
						}
					?>
					<div class="form-area">  
							<span style="clear:both"></span>
								<p>
									Photo 
									<input class="btn btn-default" name="fichier" type="file" value="<?php echo $p_admin->photo; ?>">
								</p>
								<p>
									Nom
									<input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" value="<?php echo $p_admin->nom; ?>" required>
								</p>
								<p>
									Prénom
									<input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prenom" value="<?php echo $p_admin->prenom; ?>" required>
								</p>
								<p>
									Age
									<input type="number" class="form-control input-sm" id="age" name="age" placeholder="Age" value="<?php echo $p_admin->age; ?>" min="0" max="100" required>
								</p>
								<p>
									Description
									<textarea class="form-control" type="textarea" id="description" name="description" placeholder="Description" maxlength="240" rows="3" required><?php echo $p_admin->description; ?></textarea>
								</p>
								<p>
									Exercices préférés
									<textarea class="form-control" type="textarea" id="exercicesPreferes" name="exercicesPreferes" placeholder="Exercices préférés" maxlength="100" rows="3" required><?php echo $p_admin->exercice_prefere; ?></textarea>
								</p>
								<p>
									Poids
									<input type="number" class="form-control input-sm" id="poids" name="poids" placeholder="Poids" value="<?php echo $p_admin->poids; ?>" min="0" max="180" required>
								</p>
								<p>
									Taille
									<input type="number" class="form-control input-sm" id="taille" name="taille" placeholder="Taille" value="<?php echo $p_admin->taille; ?>" min="0" max="250" required>
								</p>
								<p>
									Mensuration
									<textarea class="form-control margin-bottom" type="textarea" id="mensuration" name="mensuration" placeholder="Mensurations" maxlength="140" rows="5" required><?php echo $p_admin->mensuration; ?></textarea>
								</p>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-6">
						  <input type="submit" class="btn btn btn-success">
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
