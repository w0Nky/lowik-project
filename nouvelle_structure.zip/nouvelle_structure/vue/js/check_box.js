$(document).ready(function(e){
	var compteur = 0;

	if(compteur < 3){
		$(".img-check").click(function(){
			$(this).toggleClass("check");
			compteur = compteur + 1;
		});
	}else{
		alert('Vous pouvez sélectionner que 3 images !');
	}
});