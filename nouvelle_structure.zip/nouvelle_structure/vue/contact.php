<!-- contact -->
	<div class="container bg-3 padding-top-bottom margin-top">
		<div class="col-md-12">
			<div class="form-area">  
				<form role="form">
					<span style="clear:both"></span>
					<h3 class="well bg-3" style="text-align: center;">Formulaire de contact</h3>
					<div class="form-group">
						<input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prenom" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
					</div>
					<div class="form-group">
						<input type="text" class="form-control" id="sujet" name="sujet" placeholder="Sujet" required>
					</div>
					<div class="form-group">
						<textarea class="form-control" type="textarea" id="message" placeholder="Message" maxlength="140" rows="7"></textarea>
					</div>
					
					<button type="button" id="submit" name="submit" class="btn btn-primary pull-right">Envoyer</button>
				</form>
			</div>
		</div>
	</div>