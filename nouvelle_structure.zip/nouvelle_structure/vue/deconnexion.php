<!--<div class="contenu">-->
<?php
        header('Location: accueil');
?>
<!--</div>-->