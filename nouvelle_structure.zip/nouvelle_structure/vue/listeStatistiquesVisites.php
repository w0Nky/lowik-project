<div class="container bg-2 padding-top">
  <div class="col-lg-12"><!--
    <div class="panel panel-default">
      <form method="post" action="<?php echo ADRESSE_ABSOLUE_URL . 'listeStatistiquesVisites/' .$num_page ;?>">
        <div class="btn-toolbar">
          <button class="btn btn-primary" name="ip">Par ip</button>
          <button class="btn" name="date">Date de visites</button>
          <button class="btn" name="vue">Pages vues</button>
        </div>
      </form>
      </div>-->
      <!-- Visites -->
      <?php
          // Si le tableau est vide
          if(isset($liste_visites) && empty($liste_visites)){
                  echo '<hr><br/><p style="text-align:center;">Aucun résultat...</p>';                  
          }else{
      ?>
            <div class="well">
                <table id="myTable" class="table font-size-petit">
                  <thead class="color-blue">
                    <tr>
                      <th>IP</th>
                      <th>Date visite</th>
                      <th>Pages vues</th>
                      <th>Ville</th>
                      <th>Pays</th>
                      <th style="width: 36px;"></th>
                    </tr>
                  </thead>
                  <tbody class="color-black">
      <?php
                    $i = 0;
                    foreach($liste_visites as $visites) {
      ?>
                      <tr>
                        <td id="ip"><?php echo $visites->ip;?></td>
                        <td><?php echo $visites->date_visite;?></td>
                        <td><?php echo $visites->pages_vues;?></td>
                        <td <?php echo 'id="city'. $i .'"'?> ><?php echo ''?></td>
                        <td <?php echo 'id="country'. $i .'"'?> ><?php echo ''?></td>
                      </tr>
      <?php 
                      $i = $i + 1;
                    } // fin du foreach
          } // fin du else
      ?>
              
            </tbody>
          </table>
      </div>
    </div>
  </div>
</div>
  <!-- pagination -->
  <div class="container bg-2" id="#top">  
    <ul class="pager">
          <?php if($num_page > 1) echo '<li class="previous"><a href="' . ADRESSE_ABSOLUE_URL . 'listeStatistiquesVisites/'.($num_page - 1).'"><span aria-hidden="true">&larr;</span>précédent</a></li>'; ?>
          
      <?php echo '<li class="next"><a href="'  . ADRESSE_ABSOLUE_URL . 'listeStatistiquesVisites/'.($num_page + 1).'">suivant<span aria-hidden="true">&rarr;</span></a></li>'; ?>
    </ul>
  </div>

</div>