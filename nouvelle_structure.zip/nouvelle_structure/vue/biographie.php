<!-- Biographie -->
	<div class="container bg-1 padding-top-bottom">
		<div class="span3">
			<center>
			<a href="#aboutModal" data-toggle="modal" data-target="#myModal">
				<img src="<?php echo 'vue/uploads/biographie/photo_profil/' . $p_admin->photo; ?>" alt="<?php echo $p_admin->prenom . ' ' . $p_admin->nom; ?>" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
			</a>
			<h3><?php echo $p_admin->prenom . ' ' . $p_admin->nom; ?></h3>
			<em>Cliquez sur ma photo pour en apprendre plus ! </em>
			</center>
		</div>
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
						<h4 class="modal-title" id="myModalLabel">Plus d'informations sur <?php echo $p_admin->prenom ?></h4>
						</div>
					<div class="modal-body">
						<center>
						<img src="<?php echo PHOTO_BIOGRAPHIE_PATH . $p_admin->photo; ?>" alt="<?php echo $p_admin->prenom . ' ' . $p_admin->nom; ?>" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
						<h3 class="media-heading"><?php echo $p_admin->prenom . ' ' . $p_admin->nom; ?> <small>FR</small><img src="<?php echo IMAGES_STYLE; ?>flagFR.PNG" alt="Français!" class="img-responsive" style="height:25px; width:25px;" alt="Image"></h3>
						<span><strong class="margin-bottom">Autres : </strong></span>
							<span class="label label-warning">Poids : <?php echo $p_admin->poids .' kg'; ?></span>
							<span class="label label-info">Taille : <?php echo $p_admin->taille .' cm'; ?></span>
							<span class="label label-info">Exercices préférés : <?php echo $p_admin->exercice_prefere; ?></span>
						</center>
						<hr>
						<center>
						<p class="text-left"><strong>Description : </strong><br>
							<?php echo $p_admin->description; ?>
						</p>
						<br>
						</center>
					</div>
					<div class="modal-footer">
						<center>
						<button type="button" class="btn btn-success" data-dismiss="modal">J'en ai assez vu :p</button>
						</center>
					</div>
				</div>
			</div>
		</div>
	</div>