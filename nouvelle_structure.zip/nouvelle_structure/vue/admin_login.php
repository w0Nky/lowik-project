<div class="container bg-2 padding-top-bottom">
	<form class="form-horizontal" method="post" action="">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">COMPTE ADMINISTRATEUR</div>
				<div class="panel-body">
					<div class="form-group">
						<label for="email" class="col-sm-4 control-label color-blue" >Nom de compte</label>
						<div class="col-sm-5">
						  <input type="text" class="form-control" id="login" name="login" placeholder="Nom de compte">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-4 control-label color-blue">Mot de passe</label>
						<div class="col-sm-5">
						  <input type="password" class="form-control" id="password" name="password" placeholder="Password">
						  <input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-6">
						  <input type="submit" class="btn btn btn-success">
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
	<?php 
		if($erreur != 0 && $erreur != -1){
			echo '<p style="text-align:center;">'. $code_retour[$erreur] . '</p>';
		}
		if(isset($erreurToken) && $erreurToken == true){
			echo '<p style="text-align:center;">'. $code_retour[25] . '</p>';
		}
	?>
</div>