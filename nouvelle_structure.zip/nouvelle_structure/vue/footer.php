<?php
if($page != 'admin') {
 echo ' 	<!-- Footer -->
	<footer class="container bg-2 text-center padding-top-footer">
		<div class="row">
			<div class="col-md-11 margin-top">
				<!--<li role="separator" class="divider"></li>-->
				<p style="font-size: 12px;"> Site web fait par Kristen VIGUIER - CSS Bootstrap - <a href="#myBio">Lowik</a></p>
			</div>
			<div class="col-md-1">
				<a class="up-arrow" href="#top" data-toggle="tooltip" title="" data-original-title="TO TOP" style="color:white;">
					<span class="glyphicon glyphicon-chevron-up"></span>
				</a>
			</div>
		</div>
		<div class="row  margin-top padding-bottom">
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'facebook.ico" alt="Facebook"  class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://www.facebook.com/lowikfitt/?fref=ts\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'twitter-logo-silhouette.png" alt="Twitter" class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://twitter.com/lowikfitt\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'youtube-logotype.png" alt="Youtube"  class="img-responsive focus" style="width:50px;height:50px"  onclick="window.open(\'https://www.youtube.com/channel/UC_i-igE_T12eWoiroWXNuFw\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'instagram.png" alt="Instagram"  class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://www.instagram.com/lowikfitt/?hl=fr\');">
			</div>
			<!-- partners -->
			<div class="col-sm-2 col-sm-offset-1">
				<p>Partenaires :</p>
			</div>
			<div class="col-sm-1">
				<p class="font-size-petit">blabla</p>
			</div>
			<div class="col-sm-1">
				<p class="font-size-petit">blabla</p>
			</div>
			<div class="col-sm-1">
				<p class="font-size-petit">blabla</p>
			</div>
		</div>
	</footer> 
 ';
}
?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/bootstrap.min.js'; ?>"></script>
    <!--<script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/upload_cloner.min.js'; ?>"></script>-->
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/check_form.js'; ?>"></script>
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/localisation.js'; ?>"></script>
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/bbcode.js'; ?>"></script>
	<script>
	function sure(){
		return confirm("Es-tu sûr ?");
	}
	function confirmationSuppression(){
		return confirm("Es-tu sûr de vouloir supprimer cet article ?");
		/*if(confirm("Es-tu sûr de vouloir supprimer cet article ?")){ // Si click ok
			$('#myModal').modal('show');
		}*/
	}
	function openModal(){
		sleep(5);
		$('#myModal').modal('show');
	}
	function redirictionPath(path){
		document.location.href=path;
	}
	</script>
  </body>
</html>