<?php
if($page != 'admin') {
 echo ' 	<!-- Footer -->
	<footer class="container bg-2 text-center padding-top-footer">
		<div class="row">
			<div class="col-md-12 margin-top">
				<!--<li role="separator" class="divider"></li>-->
				<p style="font-size: 12px;">
				Blog de musculation - <a href="#myBio">Loïc Baroni</a><br>
				Developped and Designed by Kristen VIGUIER<br>
				<a class="up-arrow" href="#top" data-toggle="tooltip" title="" data-original-title="TO TOP" style="color:white; float:right; font-size:20px;">
					<span class="glyphicon glyphicon-chevron-up"></span>
				</a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 margin-top padding-bottom">
				<p style="font-size: 12px;">
					<a href="http://www.oneskyapp.com/fr/docs/bootstrap/">Bootstrap </a> - The MIT License (MIT) - Copyright (c) 2011-2016 Twitter, Inc. <br>

					Permission is hereby granted, free of charge, to any person obtaining a copy
					of this software and associated documentation files (the "Software"), to deal
					in the Software without restriction, including without limitation the rights
					to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
					copies of the Software, and to permit persons to whom the Software is
					furnished to do so, subject to the following conditions:<br>

					THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
					IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
					FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
					AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
					LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
					OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
					THE SOFTWARE
				</p>
			</div>
		</div>
		<div class="row  margin-top padding-bottom">
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'facebook.ico" alt="Facebook"  class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://www.facebook.com/lowikfitt/?fref=ts\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'twitter-logo-silhouette.png" alt="Twitter" class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://twitter.com/lowikfitt\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'youtube-logotype.png" alt="Youtube"  class="img-responsive focus" style="width:50px;height:50px"  onclick="window.open(\'https://www.youtube.com/channel/UC_i-igE_T12eWoiroWXNuFw\');">
			</div>
			<div class="col-sm-1">
				<img src="' . ADRESSE_ABSOLUE_URL . IMAGES_STYLE . 'instagram.png" alt="Instagram"  class="img-responsive focus" style="width:50px;height:50px" onclick="window.open(\'https://www.instagram.com/lowikfitt/?hl=fr\');">
			</div>
			<!-- partners -->
			<div class="col-sm-2 col-sm-offset-1">
				<p class="color-white">PARTENAIRES</p>
			</div>
			<div class="col-sm-2">
				<img src="http://m.fitnessboutique.fr/static/common/images/logo_fb.png" alt="Fitness Boutique"  class="img-responsive" onclick="window.open(\'http://albi.fitnessboutique.fr/\');">
			</div>
			<div class="col-sm-1">
				<p class="font-size-petit">blabla</p>
			</div>
			<div class="col-sm-1">
				<p class="font-size-petit">blabla</p>
			</div>
		</div>
	</footer> 
 ';
}
?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/bootstrap.min.js'; ?>"></script>
    <!--<script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/upload_cloner.min.js'; ?>"></script>-->
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/check_form.js'; ?>"></script>
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/localisation.js'; ?>"></script>
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/bbcode.js'; ?>"></script>
    <script src="<?php echo ADRESSE_ABSOLUE_URL . 'js/check_box.js'; ?>"></script>
	<script>
	function sure(){
		return confirm("Es-tu sûr ?");
	}
	function confirmationSuppression(){
		return confirm("Es-tu sûr de vouloir supprimer cet article ?");
		/*if(confirm("Es-tu sûr de vouloir supprimer cet article ?")){ // Si click ok
			$('#myModal').modal('show');
		}*/
	}
	function openModal(){
		sleep(5);
		$('#myModal').modal('show');
	}
	function redirictionPath(path){
		document.location.href=path;
	}
	</script>
  </body>
</html>