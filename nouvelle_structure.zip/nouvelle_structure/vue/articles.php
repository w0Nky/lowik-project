<!-- articles -->
<?php
    $i=0;

    // Si le tableau est vide
    if(isset($liste_articles) && empty($liste_articles)){
    	$class = 'class="container bg-1 padding-top-bottom"';
?>
	    <div <?php echo $class; ?>>
				<div class="row">
					<div class="col-sm-12">
						<p>
							Aucun résultat...
						</p>
					</div>
			</div>
		</div>
		<!-- pagination -->
		<div class="container bg-2" id="#top">  
				<ul class="pager">
			        <?php if($num_page > 1) echo '<li class="previous"><a href="' . ADRESSE_ABSOLUE_URL . 'articles/'.($num_page - 1).'"><span aria-hidden="true">&larr;</span>précédent</a></li>'; ?>
			        
				</ul>
	    </div>

<?php
    }else{
	    foreach($liste_articles as $article) {
	    	$class ='';
	    	// Effets de style
	    	if($i%2 == 0){
	    		if($i==0){
					$class = 'class="container bg-3 padding-top"';
	    		}else{
	    			$class = 'class="container bg-3 padding-top"';
	    		}
	    	}else{
	    		$class =  'class="container bg-1 padding-top"';
	    	}

?>
	    <div <?php echo $class; ?>>
			<div class="row">
				<div class="col-sm-2">
					<a href="<?php echo ADRESSE_ABSOLUE_URL.'detail_articles/'.$article->id;?>" class=""><img src="<?php echo $article->url; ?>" class="img-responsive img-shadow" width="200px" height="100px"></a>
				</div>
				<div class="col-sm-10">
					<a href="<?php echo ADRESSE_ABSOLUE_URL.'detail_articles/'.$article->id;?>" class=""><h3 class="bbcode-h3"><?php echo $article->titre; ?></h3></a>
					<p class="margin-zero">
						<?php echo $article->description; ?>
					</p>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="col-sm-offset-4">
						<p class="color-black" style="float:right;">
							Auteur : <a href="<?php echo ADRESSE_ABSOLUE_URL; ?>biographie"><?php echo $article->auteur; ?></a>
							<span class="color-black padding-left"><?php echo ' Publié le : '.$t_texte->quand($article->datePublication); ?></span>
						</p>
						
					</div>
				</div>	
			</div>
		</div>

<?php 
		$i++;
		}// Fin de la boucle foreach
?>

	<!-- pagination -->
	<div class="container bg-2" id="#top">  
			<ul class="pager">
		        <?php if($num_page > 1) echo '<li class="previous"><a href="' . ADRESSE_ABSOLUE_URL . 'articles/'.($num_page - 1).'"><span aria-hidden="true">&larr;</span>précédent</a></li>'; ?>
		        
				<?php echo '<li class="next"><a href="'  . ADRESSE_ABSOLUE_URL . 'articles/'.($num_page + 1).'">suivant<span aria-hidden="true">&rarr;</span></a></li>'; ?>
			</ul>
    </div>
<?php 
	} // fin du esle
?>
	<div class="container bg-2" id="#top">  
		<hr>
	</div>

