<!-- PARTIE GESTION DES ARTICLES UPDATE -->
<div class="container bg-2 margin-top padding-top">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">MISE A JOUR DE L'ARTICLE</div>
				<div class="panel-body" style="color:black;">
					<?php 
							if($bienModifie){

								echo '<div class="alert alert-success alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[13].' redirection dans 3 secondes...
									</div>
									';
							}else{
								echo '<div class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[14].'
									</div>';
							}
							/* REDIRECTION au bout de 3 secondes */
							echo '											
								<script>
									window.setTimeout("location=(\''.ADRESSE_ABSOLUE_URL.'gestionDetailArticle/'.$idArticle. '\');", 3000);
								</script>';
					?>	
				</div>
			</div>
		</div>
</div>
