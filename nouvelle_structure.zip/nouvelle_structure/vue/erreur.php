<div class="container bg-3 text-center padding-top-bottom" id="#myBio">
	<img src="<?php echo ADRESSE_ABSOLUE_URL.IMAGES_STYLE; ?>photo_presentation.jpg" alt="Loïc Baroni" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
	<h3 class="margin-bottom"><?php echo $message_erreur; ?></h3>
</div>