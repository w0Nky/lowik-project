<!-- PARTIE GESTION DES ARTICLES -->
<div class="container bg-2 margin-top padding-top">
	<form class="form-horizontal" method="post" action="">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					LISTE DES ARTICLES 
					<a href="<?php echo ADRESSE_ABSOLUE_URL.'gestionAjoutArticle';?>" style="float:right;">
						<button class="btn btn-default" type="button">
							<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
						</button>
					</a>
				</div>
				<div class="panel-body" style="color:black; font-size:12px;">
<!-- articles -->
<?php
    $i=0;

    // Si le tableau est vide
    if(isset($liste_articles) && empty($liste_articles)){
?>
					<div class="row">
						<div class="col-sm-12">
							<p>
								Aucun résultat...
							</p>
						</div>
					</div>			
<!-- ces divs correspondnet à la fin du container -->					
				</div>
			</div>
		</div>
	</form>
</div>

		<!-- pagination -->
		<div class="container bg-2" id="#top">  
				<ul class="pager">
			        <?php if($num_page > 1) print('<li class="previous"><a href="http://localhost/nouvelle_structure/gestionArticles/'.($num_page - 1).'"><span aria-hidden="true">&larr;</span>précédent</a></li>'); ?>
			        
				</ul>
	    </div>

<?php
    }else{
	    foreach($liste_articles as $article) {
?>
				<div class="row">
					<div class="col-sm-2">
						<a href="<?php echo ADRESSE_ABSOLUE_URL.'gestionDetailArticle/'.$article->id;?>" class=""><img src="<?php echo $article->url; ?>" class="img-responsive"></a>
					</div>
				<div class="col-sm-9">
					<a href="<?php echo ADRESSE_ABSOLUE_URL.'gestionDetailArticle/'.$article->id;?>" class=""><h3 class="title"><?php echo $article->titre; ?></h3></a>
					<p class="text-muted"><span class="glyphicon glyphicon-calendar"><?php echo ' ' . $t_texte->quand($article->datePublication) . ' ' ; ?></span></p>
					<p>
						<?php echo mb_strimwidth($article->description, 0, 200, "..."); ?>
					</p>
					<p class="text-muted">Auteur : <a href="<?php echo ADRESSE_ABSOLUE_URL; ?>biographie"><?php echo $article->auteur; ?></a></p>
				</div>
				<div class="col-sm-1">
					<form class="form-horizontal" method="post" action="" onsubmit="return confirmationSuppression()">
							<input type="hidden" name="idToDelete" value="<?php echo $article->id;?>">
							<input type="submit" class="btn btn btn-danger" value="DELETE">
					</form>
				</div>
			</div>
	

<?php 
		}// Fin de la boucle foreach
?>
<!-- ces divs correspondnet à la fin du container -->
				</div>
			</div>
		</div>
	</form>
</div>

	<!-- pagination -->
	<div class="container bg-2" id="#top">  
			<ul class="pager">
		        <?php if($num_page > 1) echo '<li class="previous"><a href="' . ADRESSE_ABSOLUE_URL . 'gestionArticles/'.($num_page - 1).'"><span aria-hidden="true">&larr;</span>précédent</a></li>'; ?>
		        
				<?php echo '<li class="next"><a href="'  . ADRESSE_ABSOLUE_URL . 'gestionArticles/'.($num_page + 1).'">suivant<span aria-hidden="true">&rarr;</span></a></li>'; ?>
			</ul>
    </div>
<?php 
	} // fin du esle
?>
		<div class="container bg-2" id="#top">  
			<hr>
		</div>


	<!-- POP UP MODAL  DE SUPRRESSIOn-->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<div class="alert alert-danger alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong>Information : </strong> article bien supprimé ! 
					</div>
					<center>
						<button type="button" class="btn btn-success" data-dismiss="modal" onclick="redirictionPath(<?php echo ADRESSE_ABSOLUE_URL.'gestionArticles'; ?>)">Ok</button>
					</center>
				</div>
			</div>
		</div>
	</div>