<div class="container bg-2 padding-top">
	<div class="col-lg-12">
		<div class="panel panel-success">
			<div class="panel-heading titre"><?php echo $p_article->titre; ?></div>
			<div class="panel-body" style="color:black;">
			
					<?php echo $p_article->texte; ?>

				<hr>
				<p class="text-muted">Publié le :  <?php echo $t_texte->quand($p_article->datePublication); ?> - <a href="<?php echo ADRESSE_ABSOLUE_URL; ?>biographie"><?php echo $p_article->auteur; ?></a></p>
			</div>
		</div>
	</div>
</div>