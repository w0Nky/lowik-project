<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo $meta_description; ?>">
	<meta name="keywords" content="<?php echo $meta_keywords; ?>">
	<meta name="Author" content="Loïc Baroni" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $nom_page;?></title>

    <!-- Bootstrap -->
    <link href="<?php echo ADRESSE_ABSOLUE_URL . BOOTSRAP_CSS; ?>" rel="stylesheet">
	<link href="<?php echo ADRESSE_ABSOLUE_URL . STYLE_CSS; ?>" rel="stylesheet">


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>


<?php 

	$elementMenu = '
					<div class="navbar-form navbar-right inline-form padding-right">
						<div class="dropdown">
							<button class="btn btn-primary dropdown-toggle btn-sm" type="button" data-toggle="dropdown"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>&nbsp;Admin menu
							<span class="caret"></span></button>
							<ul class="dropdown-menu">
								<li><a href="'.ADRESSE_ABSOLUE_URL .'dashboard">
									<button class="btn btn-primary" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-dashboard" aria-hidden="true"></span>&nbsp;Dashboard
									</button>
								</a></li>
								<li><a href="'.ADRESSE_ABSOLUE_URL .'gestionAccueil">
									<button class="btn btn-success" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Gestion de l\'accueil
									</button>
								</a></li>
								<li><a href="'.ADRESSE_ABSOLUE_URL .'gestionArticles">
									<button class="btn btn-warning" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-book" aria-hidden="true"></span>&nbsp;Gestion des articles
									</button>
								</a></li>
								<!--<li><a href="'.ADRESSE_ABSOLUE_URL .'#">
									<button class="btn btn-danger"" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-film" aria-hidden="true"></span>&nbsp;Gestion des trainings
									</button>
								</a></li>-->
								<li><a href="'.ADRESSE_ABSOLUE_URL .'gestionBiographie">
									<button class="btn btn-default" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;Gestion de la biographie
									</button>
								</a></li>
								<li><a href="#">
									<button class="btn btn-info" type="button" style="width:100%;">
										<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>&nbsp;Messages <span class="badge">4</span>
									</button>
								</a></li> 
								<li><a href="'.ADRESSE_ABSOLUE_URL .'deconnexion">
									<button class="btn btn-default" type="button" style="width:100%; background-color: #6c7782; border-color: #6c7782; color:white;">
										<span class="glyphicon glyphicon-off" aria-hidden="true"></span>&nbsp;Déconnexion
									</button>
								</a></li>

								<li role="separator" class="divider"></li>

								<li><a href="'.ADRESSE_ABSOLUE_URL .'admin_compte">
									<p style="text-align:center; color:#009fff;">Mon compte</p>
								</a></li>
							</ul>
						</div>
					</div>
					';
?>

<!-- MENU -->
<div class="container bg-2" id="#top">
  <nav class="navbar navbar-inverse">
      <div class="navbar-header navbar-inverse">
        <button type="button" class="navbar-toggle navbar-inverse collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Dérouler le menu</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      
      <div id="navbar" class="navbar-collapse navbar-inverse collapse">
		<ul class="nav navbar-nav">
			<li <?php if(strcmp($page, 'accueil') == 0 ){	echo 'class="active"'; } ?> ><a href="<?php echo ADRESSE_ABSOLUE_URL; ?>accueil">Accueil</a></li>
			<li <?php if(strcmp($page, 'articles') == 0 ){	echo 'class="active"'; } ?>><a href="<?php echo ADRESSE_ABSOLUE_URL; ?>articles">Articles</a></li>
			<!--<li <?php if(strcmp($page, 'training') == 0 ){	echo 'class="active"'; } ?>><a href="<?php echo ADRESSE_ABSOLUE_URL; ?>training">Training</a></li>-->
			<!--<li <?php if(strcmp($page, 'biographie') == 0 ){	echo 'class="active"'; } ?>><a href="<?php echo ADRESSE_ABSOLUE_URL; ?>biographie">Biographie</a></li>-->
			<li <?php if(strcmp($page, 'contact') == 0 ){	echo 'class="active"'; } ?>><a href="<?php echo ADRESSE_ABSOLUE_URL; ?>contact">Contact</a></li>						
		</ul>	
		<?php if(strcmp($page, 'articles') == 0){ ?>
			<div class="navbar-form navbar-right inline-form padding-right">
				<div class="form-group">
					<form method="POST" action="">
					  <input type="search" class="input-sm form-control" placeholder="Recherche">
					  <button type="submit" style="margin-bottom:5px;" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-search"></span> Chercher</button>
				  	</form>
				</div>
			</div>
		<?php } ?>
		<?php if(isset($_SESSION['id']) && $_SESSION['id'] == 1) echo $elementMenu; ?>
      </div><!--/.nav-collapse -->
    </div><!--/.container -->
  </nav>
</div>
	