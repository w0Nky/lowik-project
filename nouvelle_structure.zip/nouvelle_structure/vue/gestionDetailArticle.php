<!-- PARTIE GESTION DES ARTICLES -->
<div class="container bg-2 margin-top padding-top">
	<form class="form-horizontal" method="post" action="<?php echo ADRESSE_ABSOLUE_URL . 'gestionDetailArticleUpdate/' . $p_article->id; ?>">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">EDITION D'ARTICLE</div>

				<div class="panel-body" style="color:black;">
					<div class="form-group margin-zero">
					<?php 
							if($champsMalSaisie){

								echo '<div class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<strong>Information : </strong>'.$code_retour[4].'
									</div>';
							}
					?>	
					</div>

					<div class="form-area margin-zero">  
							<span style="clear:both"></span>
								<p>
									Titre <input type="text" class="form-control" id="titre" name="titre" value="<?php echo $p_article->titre; ?>" required>
								</p>

								<p>
									URL OU image vignette 
									<input type="text" class="form-control" id="lienVignette" name="lienVignette" value="<?php echo $p_article->url; ?>">	
									<input class="btn btn-default" name="imgVignette" type="file">
								</p>

								<p>Description 
									<div class="btn-group">
										<button type="button" class="btn btn-primary" title="Gras"  onclick="gras(description)"><span class="glyphicon glyphicon-bold"></span></button>
										<button type="button" class="btn btn-primary" title="Italic" onclick="italic(description)"><span class="glyphicon glyphicon-italic"></span></button>
										<button type="button" class="btn btn-primary" title="Souligné" onclick="souligne(description)"><b>U</b></button>
										<button type="button" class="btn btn-primary" title="Gauche" onclick="gauche(description)"><span class="glyphicon glyphicon-align-left"></span></button>
										<button type="button" class="btn btn-primary" title="Centré" onclick="centré(description)"><span class="glyphicon glyphicon-align-center"></span></button>
										<button type="button" class="btn btn-primary" title="Droite" onclick="droite(description)"><span class="glyphicon glyphicon-align-right"></span></button>
										<button type="button" class="btn btn-primary" title="Justifié" onclick="justifie(description)"><span class="glyphicon glyphicon-align-justify"></span></button>
										<button type="button" class="btn btn-primary" title="Liste à puces" onclick="listePuces(description)"><span class="glyphicon glyphicon-list"></span></button>
										<button type="button" class="btn btn-primary" title="Image" onclick="image(description)"><span class="glyphicon glyphicon-picture"></span></button>
										<button type="button" class="btn btn-primary" title="Lien" onclick="lien(description)"><span class="glyphicon glyphicon-link"></span></button>
										<button type="button" class="btn btn-primary" title="Titre 1" onclick="titre1(description)">T<sub>1</sub></button>
										<button type="button" class="btn btn-primary" title="Titre 2" onclick="titre2(description)">T<sub>2</sub></span></button>
										<button type="button" class="btn btn-primary" title="Titre 3" onclick="titre3(description)">T<sub>3</sub></span></button>
									</div>
									<textarea class="form-control" type="textarea" id="description"  name="description" maxlength="140" rows="5"  required><?php echo $t_texte->convertHtmlToBBcode($p_article->description); ?></textarea>
								</p>

								<p>Contenu 
									<div class="btn-group">
										<button type="button" class="btn btn-primary" title="Gras"  onclick="gras(texte)"><span class="glyphicon glyphicon-bold"></span></button>
										<button type="button" class="btn btn-primary" title="Italic" onclick="italic(texte)"><span class="glyphicon glyphicon-italic"></span></button>
										<button type="button" class="btn btn-primary" title="Souligné" onclick="souligne(texte)"><b>U</b></button>
										<button type="button" class="btn btn-primary" title="Gauche" onclick="gauche(texte)"><span class="glyphicon glyphicon-align-left"></span></button>
										<button type="button" class="btn btn-primary" title="Centré" onclick="centré(texte)"><span class="glyphicon glyphicon-align-center"></span></button>
										<button type="button" class="btn btn-primary" title="Droite" onclick="droite(texte)"><span class="glyphicon glyphicon-align-right"></span></button>
										<button type="button" class="btn btn-primary" title="Justifié" onclick="justifie(texte)"><span class="glyphicon glyphicon-align-justify"></span></button>
										<button type="button" class="btn btn-primary" title="Liste à puces" onclick="listePuces(texte)"><span class="glyphicon glyphicon-list"></span></button>
										<button type="button" class="btn btn-primary" title="Image" onclick="image(texte)"><span class="glyphicon glyphicon-picture"></span></button>
										<button type="button" class="btn btn-primary" title="Lien" onclick="lien(texte)"><span class="glyphicon glyphicon-link"></span></button>
										<button type="button" class="btn btn-primary" title="Titre 1" onclick="titre1(texte)">T<sub>1</sub></button>
										<button type="button" class="btn btn-primary" title="Titre 2" onclick="titre2(texte)">T<sub>2</sub></span></button>
										<button type="button" class="btn btn-primary" title="Titre 3" onclick="titre3(texte)">T<sub>3</sub></span></button>
									</div>
									<textarea class="form-control" type="textarea" id="texte" name="texte" placeholder="Message" rows="20"  required><?php echo $t_texte->convertHtmlToBBcode($p_article->texte); ?></textarea>
								</p>
								<input type="hidden" name="soumis" value="TRUE" />
					</div>
					<div class="form-group">
						<div class="col-sm-offset-6">
						  <input type="submit" class="btn btn btn-success">
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
