<!-- menu vertical admin et aside -->
<div class="container bg-2 padding-top">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Bonjour <b><?php echo $_SESSION['prenom'];?></b> ! Bienvenue sur le dashboard :)</div>
			<div class="panel-body" style="color:black;">
				<p>
					Ici se trouve la partie <i>administrateur</i>. <br />
					Tu peux constater en haut à droite la présence d'un nouvel onglet "Admin Menu".<br />
					Grâce à lui tu vas pouvoir éditer toutes les pages de ton site comme bon te semble.<br />
					<ul>
						<li>Dashboard - te renvoie sur cette même page</li>
						<li>Gestion de l'accueil - permet de modifier des informations, des photos... de la page d'accueil</li>
						<li>Gestion des articles - permet d'ajouter de nouveaux articles, d'en supprimer, d'en modifier</li>
						<li>Gestion des trainings - permet d'ajouter de nouveaux trainings, d'en supprimer, d'en modifier</li>
						<li>Gestion de la biographie - permet de modifier ta bio</li>
						<li>Déconnexion - pas besoin d'explications :p</li>
					</ul>
				</p>
				<hr>
				<div class="alert alert-danger" role="alert">
					<p> Attention ! Ne divulge jamais ton <b>compte</b> sinon des personnes mal attentionés peuvent tout supprimer ou modifier ou ajouter des choses...</p>
				</div>
			</div>
			<div class="panel-footer">
				<p class="font-size-petit color-black"> 
					Il y a <?php echo $nbUserConnecte['nb'];?> utilisateur(s) connecté(s) sur le site 
					-
					Nombre de visites totales : <?php echo $get_nbr_visite['nbVisite'];?>
					-
					Nombre totales de pages vue : <?php echo $get_nbr_visite['nbPageVues'];?>
					<a href="<?php echo ADRESSE_ABSOLUE_URL .'listeStatistiquesVisites'; ?>" class="float-right">Plus de détails</a>
				</p>
			</div>
		</div>
	</div>

	<!--<div class="col-lg-5">
		<div class="panel panel-default">
			<div class="panel-heading">Télécharger des images</div>
			<div class="panel-body">
				<div class="controls">
					<div class="entry input-group col-lg-12">
						<input class="btn btn-default" name="fields[]" type="file">
						<span class="input-group-btn">
						<button class="btn btn-grey btn-add" type="button">
							<span class="glyphicon glyphicon-plus"></span>
						</button>
						</span>
					</div>
				</div>
			</div>
		</div>
	</div>-->
</div>