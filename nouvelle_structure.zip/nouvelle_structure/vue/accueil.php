	<!-- premier container -->
    <div class="container bg-2">
	<!-- carrousel -->
		<div id="myCarousel" class="carousel slide bg-2" data-ride="carousel">

			<!-- Indicators -->
			<ol class="carousel-indicators">
				<?php 
					// On affiche le nombre li correspondant aux nombres de sliders actifs
					for($i=0;$i<$nbrActif->nbr;$i++){
				?>
					<li data-target="#myCarousel" data-slide-to="<?php echo $i; ?>" <?php if($i==0){ echo 'class="active"'; } ?> ></li>
				<?php
					}
				?>
			</ol>

			<!-- Wrapper for slides -->
			<div class="carousel-inner" role="listbox">
				<?php
					$i = 0;
					// On affiche les sliders actifs
					foreach($liste_sliders_actifs as $sliderActif){
				?>
					<div <?php if($i==0){ echo 'class="item active"'; }else{ echo 'class="item"'; } ?> >
						<img src="<?php echo ADRESSE_ABSOLUE_URL. $sliderActif->path . $sliderActif->nom ; ?>" alt="<?php echo $sliderActif->titre; ?>" style="width:100%; height:500px;">
					</div>
				<?php
					$i++;
					}
				?>

			</div>

			<!-- Left and right controls -->
			<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:white;"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:white;"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
	</div>

	<!-- 2 container about admin -->
	<div class="container bg-3 text-center padding-top-bottom" id="#myBio">
		<h3 class="margin-bottom color-white">Qui suis-je?</h3>
		<div class="row">
			<a  href="#aboutModal" data-toggle="modal" data-target="#myModal">
				<img src="<?php echo PHOTO_BIOGRAPHIE_PATH . $informationBio->photo; ?>" alt="<?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?>" class="img-responsive img-thumbnail margin-bottom img-shadow" style="width:50%" alt="Image">
			</a>
		</div>
		<a class="btn btn-info" href="#aboutModal" data-toggle="modal" data-target="#myModal">Plus d'info »</a>
	</div>

	<!-- 3 container - corresponding to last articles -->
	<div class="container bg-1 text-center padding-top-bottom">
		<h3 class="margin-bottom">Les derniers articles à ne pas râter !</h3><br>
		<div class="row">
			
			<!-- list 3 last articles -->
			<?php foreach($lastArticles as $lastArticle){ ?>

				<div class="col-sm-6 col-md-4">
					<div class="thumbnail">
						<a href="<?php echo ADRESSE_ABSOLUE_URL . 'detail_articles/' . $lastArticle->id; ?>" role="button">
							<img src="<?php echo $lastArticle->url; ?>" style="width:250px;height:250px" class="img-responsive img-thumbnail margin-bottom blur img-shadow">
						</a>
						<div class="caption">
							<p class="bbcode-p"><?php echo $lastArticle->description; ?></p><br>
							<a class="color-white hover-color-white" href="<?php echo ADRESSE_ABSOLUE_URL . 'detail_articles/' . $lastArticle->id; ?>"><button type="button" class="btn btn-warning btn-circle btn-xl"><i class="glyphicon glyphicon-search"></i></button></a>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>


	<!-- Modal  biographie -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
					<h4 class="modal-title" id="myModalLabel">Qui suis-je ?</h4>
					</div>
				<div class="modal-body">
					<center>
					<img src="<?php echo PHOTO_BIOGRAPHIE_PATH . $informationBio->photo; ?>" alt="<?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?>" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
					<h3 class="media-heading"><?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?> <small>FR</small><img src="<?php echo IMAGES_STYLE; ?>flagFR.PNG" alt="Français!" class="img-responsive" style="height:25px; width:25px;" alt="Image"></h3>
					<span><strong class="margin-bottom">Autres : </strong></span>
						<span class="label label-warning">Poids : <?php echo $informationBio->poids .' kg'; ?></span>
						<span class="label label-info">Taille : <?php echo $informationBio->taille .' cm'; ?></span>
						<span class="label label-info">Exercices préférés : <?php echo $informationBio->exercice_prefere; ?></span>
					</center>
					<hr>
					<center>
					<p class="text-left"><strong>Description : </strong><br>
						<?php echo $informationBio->description; ?>
					</p>
					<br>
					</center>
				</div>
				<div class="modal-footer">
					<center>
					<button type="button" class="btn btn-success" data-dismiss="modal">J'en ai assez vu :p</button>
					</center>
				</div>
			</div>
		</div>
	</div>