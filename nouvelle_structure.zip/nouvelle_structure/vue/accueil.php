	<!-- premier container -->
    <div class="container bg-2 margin-top">
	<!-- carrousel -->
		<div id="myCarousel" class="carousel slide bg-2" data-ride="carousel">

		  <!-- Indicators -->
		  <ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
			<li data-target="#myCarousel" data-slide-to="3"></li>
		  </ol>

		  <!-- Wrapper for slides -->
		  <div class="carousel-inner" role="listbox">
			<div class="item active">
			  <img src="<?php echo ADRESSE_ABSOLUE_URL. IMAGES_STYLE; ?>1.jpg" alt="" style="width:100%; height:500px;">
			</div>

			<div class="item">
			  <img src="<?php echo ADRESSE_ABSOLUE_URL.IMAGES_STYLE; ?>2.jpg" alt=""  style="width:100%; height:500px;">
			</div>

			<div class="item">
			  <img src="<?php echo ADRESSE_ABSOLUE_URL.IMAGES_STYLE; ?>3.jpg" alt=""  style="width:100%; height:500px;">
			</div>

			<div class="item">
			  <img src="<?php echo ADRESSE_ABSOLUE_URL.IMAGES_STYLE; ?>4.jpg" alt=""  style="width:100%; height:500px;">
			</div>

		  </div>

		  <!-- Left and right controls -->
		  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:white;"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:white;"></span>
			<span class="sr-only">Next</span>
		  </a>
		</div>
	</div>

	<!-- 2 container about admin -->
	<div class="container bg-3 text-center padding-top-bottom" id="#myBio">
		<h3 class="margin-bottom">Qui suis-je?</h3>
		<div class="row">
			<img src="<?php echo PHOTO_BIOGRAPHIE_PATH . $informationBio->photo; ?>" alt="<?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?>" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
		</div>
		<a class="btn btn-info" href="#aboutModal" data-toggle="modal" data-target="#myModal">Plus d'info »</a>
	</div>

	<!-- 3 container - corresponding to last articles -->
	<div class="container bg-1 text-center padding-top-bottom">
		<h3 class="margin-bottom">Les derniers articles à ne pas râter !</h3><br>
		<div class="row">
			
			<!-- list 3 last articles -->
			<?php foreach($lastArticles as $lastArticle){ ?>

				<div class="col-sm-4">
					<a href="<?php echo ADRESSE_ABSOLUE_URL . 'detail_articles/' . $lastArticle->id; ?>" role="button">
						<img src="<?php echo $lastArticle->url; ?>" style="width:250px;height:250px" class="img-responsive img-thumbnail margin-bottom blur">
					</a>
					<p><?php echo $lastArticle->description; ?></p>
					<p><a class="btn btn-default" href="<?php echo ADRESSE_ABSOLUE_URL . 'detail_articles/' . $lastArticle->id; ?>" role="button">View details »</a></p>
				</div>
			<?php } ?>
		</div>
	</div>


	<!-- Modal  biographie -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
					<h4 class="modal-title" id="myModalLabel">Qui suis-je ?</h4>
					</div>
				<div class="modal-body">
					<center>
					<img src="<?php echo PHOTO_BIOGRAPHIE_PATH . $informationBio->photo; ?>" alt="<?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?>" class="img-responsive img-thumbnail margin-bottom" style="width:50%" alt="Image">
					<h3 class="media-heading"><?php echo $informationBio->prenom . ' ' . $informationBio->nom; ?> <small>FR</small><img src="<?php echo IMAGES_STYLE; ?>flagFR.PNG" alt="Français!" class="img-responsive" style="height:25px; width:25px;" alt="Image"></h3>
					<span><strong class="margin-bottom">Autres : </strong></span>
						<span class="label label-warning">Poids : <?php echo $informationBio->poids .' kg'; ?></span>
						<span class="label label-info">Taille : <?php echo $informationBio->taille .' cm'; ?></span>
						<span class="label label-info">Exercices préférés : <?php echo $informationBio->exercice_prefere; ?></span>
					</center>
					<hr>
					<center>
					<p class="text-left"><strong>Description : </strong><br>
						<?php echo $informationBio->description; ?>
					</p>
					<br>
					</center>
				</div>
				<div class="modal-footer">
					<center>
					<button type="button" class="btn btn-success" data-dismiss="modal">J'en ai assez vu :p</button>
					</center>
				</div>
			</div>
		</div>
	</div>