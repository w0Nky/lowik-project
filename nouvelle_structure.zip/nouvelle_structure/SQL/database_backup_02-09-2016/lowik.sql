-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 02 Septembre 2016 à 14:20
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `lowik`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `titre` text NOT NULL,
  `texte` text NOT NULL,
  `description` text NOT NULL,
  `url` varchar(300) NOT NULL,
  `datePublication` int(11) NOT NULL,
  `auteur` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` (`id`, `titre`, `texte`, `description`, `url`, `datePublication`, `auteur`) VALUES
(23, 'article 1', '																											test', '																											test																								', 'http://ds1.static.rtbf.be/article/image/770x433/b/2/e/43d762ca733a839226415450b0dbf9d2-1460028494.jpg', 1472738168, 'Loïc Baroni'),
(24, 'Articles 2 modification', '									blalblalblablablba								', '									blablablal						azeeeeeeeeeeeeeeeeeeeeeeee		', 'https://i.ytimg.com/vi/AclEUAoYF2E/maxresdefault.jpg', 1472737043, 'Loïc Baroni');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_connectes`
--

CREATE TABLE `cpt_connectes` (
  `ip` varchar(255) COLLATE latin1_german2_ci NOT NULL,
  `timestamp` varchar(255) COLLATE latin1_german2_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german2_ci;

--
-- Contenu de la table `cpt_connectes`
--

INSERT INTO `cpt_connectes` (`ip`, `timestamp`) VALUES
('::1', '1472826016');

-- --------------------------------------------------------

--
-- Structure de la table `cpt_visites`
--

CREATE TABLE `cpt_visites` (
  `ip` varchar(30) NOT NULL,
  `date_visite` date NOT NULL,
  `pages_vues` smallint(5) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `cpt_visites`
--

INSERT INTO `cpt_visites` (`ip`, `date_visite`, `pages_vues`) VALUES
('::1', '2016-09-01', 28),
('173.250.41.23', '2016-08-31', 23),
('::1', '2016-09-02', 25),
('195.81.227.18', '2016-09-02', 3),
('66.249.64.0', '2016-09-08', 2),
('216.239.32.0', '2016-09-29', 9),
('173.194.67.100', '2016-09-01', 3),
('173.194.67.101', '2015-08-01', 3),
('173.194.67.102', '2016-04-01', 3),
('173.194.67.103', '2016-02-01', 3),
('173.194.67.104', '2016-01-01', 3),
('173.194.67.105', '2016-10-01', 3),
('173.194.67.106', '2016-11-01', 3),
('173.194.67.107', '2016-12-01', 3),
('46.108.1.182', '2016-09-02', 54),
('74.125.141.99', '2016-09-02', 2),
('46.108.1.182', '2026-09-02', 54),
('173.194.34.166', '2016-09-02', 2),
('58.27.108.187', '2016-09-02', 54),
('209.85.229.104', '2016-09-02', 2),
('201.191.202.178', '2016-09-02', 54),
('74.125.230.75', '2016-09-02', 2);

-- --------------------------------------------------------

--
-- Structure de la table `loic`
--

CREATE TABLE `loic` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(300) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `poids` decimal(10,0) NOT NULL,
  `taille` decimal(10,0) NOT NULL,
  `exercice_prefere` text NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  `mensuration` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `loic`
--

INSERT INTO `loic` (`id`, `login`, `password`, `email`, `nom`, `prenom`, `age`, `poids`, `taille`, `exercice_prefere`, `description`, `photo`, `mensuration`) VALUES
(1, 'lowikfitness', 'a184ebbf0fb95211de38b9bc2be7e6c8dc55f69527af327c28ce6c15615d4757', 'lowikfitness@gmail.com', 'Loïc', 'Baroni', 26, '94', '185', 'SQUATS, SDT', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sem dui, tempor sit amet commodo a, vulputate vel tellus.', '', 'Bras : 78 cm\r\nCuisse : 10020M\r\npec : 2mm');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `cpt_visites`
--
ALTER TABLE `cpt_visites`
  ADD PRIMARY KEY (`ip`,`date_visite`);

--
-- Index pour la table `loic`
--
ALTER TABLE `loic`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT pour la table `loic`
--
ALTER TABLE `loic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
