<?php
	/* CHEMINS */
	define('DS', '/'); //DIRECTORY_SEPARATOR
	define('ROOT', dirname(dirname(__FILE__)));


	/* BASE DE DONNEE */
	define('CONST_DB_HOST', "localhost");
	define('CONST_DB_PORT', "3307");
	define('CONST_DB_NAME', "lowik");
	define('CONST_DB_USER', "root");
	define('CONST_DB_PASS', "");
	
	/* PARAMETRES */
	define('AFFICHER_ERREURS', true);
	define('PAGE_DEFAUT', 'accueil');
	define('TIMEOUT_CONNEXION', 2592000);
	define('TIMEOUT_MOBILE_SESSION', 3600);
	define('NB_ELEMENT_PAGE', 10);
	define('NB_ELEMENT_PAGE_LISTE_STATISTIQUES', 15);
	define('NB_TENTATIVE_SOUMISSION', 5);
	define('TEMPS_AVANT_NOUVELLE_TENTATIVE_SOUMISSION', 5);
	define('TAILLE_MINIMAL_PASSWORD', 10);

    /* CHAINES */
    define('NOM_PAGE_DEFAUT', 'Blog musculation - Loïc Baroni');
    define('DESCRIPTION_DEFAUT', 'Après 3 ans de muscu me voilà avec 30 kg en plus shredded ! Un p\'tit gars maigre de base qui cherche juste à se dépasser & à être meilleur qu\'hier. Juste partager ma petite expérience !');
    define('KEYWORDS_DEFAUTS', 'fitfam fitness InShape TeamShape Damn Enorme et sec shredded squat deadlift');

    /* PATH  */
    define('BOOTSRAP_CSS', './css/bootstrap.css');
    define('STYLE_CSS', './vue/css/style.css');
    define('IMAGES_STYLE', 'vue/images/');
    define('ADRESSE_ABSOLUE_URL', 'http://172.30.253.200/nouvelle_structure/');


    /* INCLUSION DE FICHIERS CONF */
    require_once('pages_existantes.php');
    require_once('upload_file_config.php');
    require_once('code_retour.php');

?>