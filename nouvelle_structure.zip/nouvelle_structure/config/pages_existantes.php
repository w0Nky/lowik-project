<?php
	$pages_existantes = array(
			'erreur', 'accueil', 'admin_login', 'articles', 'detail_articles',
			'training', 'biographie', 'contact', 'deconnexion', 'dashboard',
			'gestionAccueil', 'gestionBiographie', 'admin_compte' , 'gestionArticles',
			'gestionDetailArticle', 'gestionAjoutArticle', 'gestionDetailArticleUpdate',
			'listeStatistiquesVisites', 'hacked'
		);
?>