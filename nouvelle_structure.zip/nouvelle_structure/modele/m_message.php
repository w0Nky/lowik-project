<?php
	class m_message{

		private $base_de_donnee;
		
		public function __construct($base_de_donnee){
			$this->base_de_donnee = $base_de_donnee;
		}
        
        /*
            PERMET DE LISTE L'ENSEMBLE DES MESSAGES
        */
		public function liste_message($numPage) {
            // Calcul num page - 1 * nbr element par page 
            $calcul = ($numPage - 1) * NB_ELEMENT_PAGE;
     
			$liste_message = $this->base_de_donnee->prepare('SELECT * FROM messagecontact LIMIT ?, '.NB_ELEMENT_PAGE);
            $liste_message->bindValue(1, $calcul, PDO::PARAM_INT);
			$liste_message->execute();
        
			$retour = $liste_message->fetchAll(PDO::FETCH_OBJ);
			$liste_articles->closeCursor();
        
			return $retour;
		}

        /*
            PERMET D'OBTENIR UN MESSAGE
        */    
        public function get_message($id){
            $get_message = $this->base_de_donnee->prepare('SELECT * FROM messagecontact WHERE id=?');
            $get_message->bindValue(1, $id, PDO::PARAM_INT);
            $get_message->execute();
            
            $retour = $get_message->fetch(PDO::FETCH_OBJ);
            $get_message->closeCursor();
                
            return $retour;
        }

        /*
            PERMET D'AJOUTER UN MESSAGE
        */    
        public function add_message($nom, $prenom, $email, $sujet, $message, $dateEnvoie, $lu){
            $add_message = $this->base_de_donnee->prepare('INSERT INTO messagecontact (nom, prenom, email, sujet, message, dateEnvoie, lu) 
            values (?, ?, ?, ?, ?, ?, ?) ');
            $add_message->bindValue(1, $nom, PDO::PARAM_STR);
            $add_message->bindValue(2, $prenom, PDO::PARAM_STR);
            $add_message->bindValue(3, $email, PDO::PARAM_STR);
            $add_message->bindValue(4, $sujet, PDO::PARAM_STR);
            $add_message->bindValue(5, $message, PDO::PARAM_STR);
            $add_message->bindValue(6, $dateEnvoie, PDO::PARAM_STR);
            $add_message->bindValue(7, $lu, PDO::PARAM_BOOL);
            $add_message->execute();
        }
    
        /*
            PERMET DE SUPPRIMER UN ARTICLE
        */    
        public function delete_message($id){
            $delete_message = $this->base_de_donnee->prepare('DELETE FROM messagecontact WHERE id = ?');
            $delete_message->bindValue(1, $id, PDO::PARAM_INT);
            $delete_message->execute();
        }
}
?>