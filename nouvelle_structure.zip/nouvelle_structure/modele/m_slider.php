<?php
	class m_slider{

		private $base_de_donnee;
		
		public function __construct($base_de_donnee){
			$this->base_de_donnee = $base_de_donnee;
		}
        
        /*
            PERMET DE LISTE L'ENSEMBLE DES SLIDERS
        */
		public function listerSlider() {
			$listerSlider = $this->base_de_donnee->prepare('SELECT * FROM sliders');
			$listerSlider->execute();
        
			$retour = $listerSlider->fetchAll(PDO::FETCH_OBJ);
			$listerSlider->closeCursor();
        
			return $retour;
		}

        /*
            PERMET D'OBTENIR UN SLIDER
        */    
        public function get_slider($id){
            $get_slider = $this->base_de_donnee->prepare('SELECT * FROM sliders WHERE id=?');
            $get_slider->bindValue(1, $id, PDO::PARAM_INT);
            $get_slider->execute();
            
            $retour = $get_slider->fetch(PDO::FETCH_OBJ);
            $get_slider->closeCursor();
                
            return $retour;
        }

        /*
            PERMET DE METTRE A JOUR UN SLIDER
        */    
        public function update_slider($id, $path, $lien, $titre){
            $update_slider = $this->base_de_donnee->prepare('UPDATE sliders SET  path = ?, lien = ?, titre = ? WHERE id = ?');

            $update_slider->bindValue(1, $path, PDO::PARAM_STR);
            $update_slider->bindValue(2, $lien, PDO::PARAM_STR);
            $update_slider->bindValue(3, $titre, PDO::PARAM_STR);
            $update_slider->bindValue(4, $id, PDO::PARAM_INT);
            $update_slider->execute();
        }
}
?>