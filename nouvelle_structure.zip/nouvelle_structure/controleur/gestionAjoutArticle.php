<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/f_formulaire.php');

	require_once('class/c_session.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_admin.php');
	require_once('modele/m_articles.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();
    $f_formulaire = new f_formulaire();

	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);

    $m_admin = new m_admin($base_de_donnee);
    $m_articles = new m_articles($base_de_donnee);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);
	
	if($_SESSION['id'] != 1) header('Location: accueil'); // Si l'id est différent de 1 : alors ce n'est pas l'admin

	$bienEnvoye = false;
	$champsMalSaisie = false;
	$autoriserMaj = false;
	$urlFichierWrong = false;

	/** On liste les articles */
	if(!empty($url_param[0])) {
		if(preg_match('#^[0-9]{1,}$#', $url_param[0])) {
			$num_article = $url_param[0];
		} else { $num_article = 1; }
	} else { $num_article = 1; }

	if(isset($_POST['titre']) && isset($_POST['description']) && isset($_POST['texte'])){

		if(!empty($_POST['titre']) && !empty($_POST['description']) && !empty($_POST['texte'])){


			/* GESTION PARTIE URL OU VIGNETTE */
			if(isset($_POST['lienVignette']) && !empty($_POST['lienVignette'])){
				$url = $_POST['lienVignette'];
				$autoriserMaj = true;
			}else{ // Ajout du fichier
				// Mise à jour de la photo
				$nomFichier = md5(uniqid());
				$target = ARTICLES_VIGNETTE_DIR;

				$codeRetour = $f_formulaire->uploadPicture($_FILES, $target, $nomFichier);
				if($codeRetour == 17){
					$nomFichier = $nomFichier .'.'.strtolower(substr(strrchr($_FILES['fichier']['name'], '.'),1));; // on récupère l'extension
					$url = ADRESSE_ABSOLUE_URL . $target . $nomFichier;
					$autoriserMaj = true;
				}else{
					$url = '';
				}
			}

			if($autoriserMaj){
				$titre = $f_formulaire->testInputData($_POST['titre']);
				// bbcode description et texte
				$description = $t_texte->convertBBcodeToHtml($_POST['description']);
				$texte = $t_texte->convertBBcodeToHtml($_POST['texte']);
			
				/* On récupère les données en session */
				$auteur = $_SESSION['nom'] . ' ' . $_SESSION['prenom'];
				$datePublication = time();

				//Appel de la fonction ajouter article
				$m_articles->add_articles($titre, $texte, $description, $url, $datePublication, $auteur);

				if($m_articles){
					$bienEnvoye = true;
				}
			}else{
				$urlFichierWrong = true;
			}
		}else{
			$champsMalSaisie = true;
		}
	}
?>