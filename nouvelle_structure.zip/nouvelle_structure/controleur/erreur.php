<?php
    $_SESSION['id'] = 0;

    if(!isset($message_erreur)) $message_erreur = "Une erreur est survenue.";

    $nom_page = 'Erreur - '.NOM_PAGE_DEFAUT;
?>