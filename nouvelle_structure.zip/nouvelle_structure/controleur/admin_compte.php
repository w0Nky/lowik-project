<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');

    require_once('class/c_session.php');
    require_once('class/c_utilisateur.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_admin.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();

	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);

	$m_admin= new m_admin($base_de_donnee);
	$c_utilisateur = new c_utilisateur($m_admin);

    /**** VERIF SESSION ****/
    $c_session->session();
    $c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);
    

    if($_SESSION['id'] != 1) header('Location: accueil'); // Si l'id est différent de 1 : alors ce n'est pas l'admin

    // Titre de la page
    $nom_page = 'Mon Compte - '.NOM_PAGE_DEFAUT;


    $p_adminInfo = $m_admin->obtenir_information_admin(1);

    $mdpKO = false;
    $modifOk = false;
    $champVide = false;
    $mdpTropCourt = false;
    $regex = "[A-Z]"               + //commence par une majuscule
               "(?=(.*[a-z]){2,})"   + //contient au moins deux minuscule
               "(?=(.*[0-9]){2,})"   + //contient au moins deux chiffres
               "(?=(.*\\W)+})"       + //contient au moins un caractère spécial
               "(?!.*\\|)"; //ne contient pas de '|'

    if(isset($_POST['login']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['passwordConfirmation'])){
		$login = $_POST['login'];
		$email = $_POST['email'];
		
		if(strlen($_POST['password']) >= 12) {
			if($_POST['password'] == $_POST['passwordConfirmation']){
				$password = $_POST['password'];

				$m_admin->mise_a_jour_compte_admin($_SESSION['id'], $login, $password, $email);
				$modifOk = true;
			}else{
				$mdpKO = true;
			}
		}else{
			$mdpTropCourt = true;
		}
    }else{
    	$champVide = true;
    }	
    	
?>