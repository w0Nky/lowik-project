<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/c_utilisateur.php');
	require_once('class/c_session.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_articles.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();

	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);

    $m_articles = new m_articles($base_de_donnee);
    $c_utilisateur = new c_utilisateur($m_session);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);
	$m_session->compter_visite($_SERVER['REMOTE_ADDR'], date('Y-m-d')); // Sous forme AAAA-mm-dd

	
	if(!empty($url_param[0])) {
		if(preg_match('#^[0-9]{1,}$#', $url_param[0])) {
			$num_article = $url_param[0];
		} else { $num_article = 1; }
	} else { $num_article = 1; }

    $p_article = $m_articles->get_articles($num_article);

    if(!$p_article){ header('Location: '.ADRESSE_ABSOLUE_URL.'articles');}