<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/f_formulaire.php');
    require_once('class/c_utilisateur.php');
	require_once('class/c_session.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_admin.php');
	require_once('modele/m_articles.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();
    $f_formulaire = new f_formulaire();

	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);
    $m_admin = new m_admin($base_de_donnee);
    $c_utilisateur = new c_utilisateur($m_admin);
    $m_articles = new m_articles($base_de_donnee);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);

	if($_SESSION['id'] != 1) header('Location: accueil'); // Si l'id est différent de 1 : alors ce n'est pas l'admin

	$bienModifie = false;
	$champsMalSaisie = false;


	/** On liste les articles */
	if(!empty($url_param[0])) {
		if(preg_match('#^[0-9]{1,}$#', $url_param[0])) {
			$num_article = $url_param[0];
		} else { $num_article = 1; }
	} else { $num_article = 1; }

    $p_article = $m_articles->get_articles($num_article);

    if(!$p_article){ header('Location: '.ADRESSE_ABSOLUE_URL.'dashboard');}
    
    if(!isset($_POST['titre']) && !isset($_POST['description']) && !isset($_POST['texte']) && !isset($_POST['lienVignette'])){
    	if(isset($_POST['soumis']) && $_POST['soumis']){
			if(empty($_POST['titre']) || empty($_POST['description']) || empty($_POST['texte'])){
					$champsMalSaisie = true;
			}	
		}
	}

?>