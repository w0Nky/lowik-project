<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/c_utilisateur.php');
    require_once('class/f_formulaire.php');
	require_once('class/c_session.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_message.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();
    $f_formulaire = new f_formulaire();
	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);
	$c_utilisateur = new c_utilisateur($m_session);
	$m_message = new m_message($base_de_donnee);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);
	$m_session->compter_visite($_SERVER['REMOTE_ADDR'], date('Y-m-d')); // Sous forme AAAA-mm-dd


	if(!empty($url_param[0])) {
		if(preg_match('#^[0-9]{1,}$#', $url_param[0])) {
			$num_page = $url_param[0];
		} else { $num_page = 1; }
	} else { $num_page = 1; }

	/* Soumission du formulaire */
	if(isset($_POST['nom']) && isset($_POST['prenom']) &&  isset($_POST['email']) &&  isset($_POST['sujet']) &&  isset($_POST['message'])){
		$ajouterMessage = false;

		// On vérifie les données !
		if($f_formulaire->verify_name($_POST['nom']) == 0){
			$nom = $_POST['nom'];
		}else{
			$codeRetour = 8;
			exit;
		}
		if($f_formulaire->verify_name($_POST['prenom']) == 0){
			$prenom = $_POST['prenom'];
		}else{
			$codeRetour = 8;
			exit;
		}
		if($f_formulaire->verify_email($_POST['email']) == 0){
			$email = $_POST['email'];
		}else{
			$codeRetour = 9;
			exit;
		}
		// Déspécialisation plus non exécution du code
		$sujet = $f_formulaire->testInputData($_POST['sujet']);
		$message = $f_formulaire->testInputData($_POST['message']);
		$dateEnvoie = time();
		$lu = false;
		// première venue
		if(!isset($_SESSION['token_time'])){
			$_SESSION['token_time'] = time();
			$ajouterMessage  = true;
		}else{
			if($c_session->isAllowToSendNewContactRequest($_SESSION) == 1 ){ // ok
				$ajouterMessage = true;
			}else{
				$codeRetour = 26;
			}
		}

		if($ajouterMessage){
			// execution fonction modele
			$m_message->add_message($nom, $prenom, $email, $sujet, $message, $dateEnvoie, $lu);
		}
	}
    
?>