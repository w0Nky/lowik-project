<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/f_formulaire.php');
	require_once('class/c_session.php');
	require_once('class/c_utilisateur.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_admin.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();
	$f_formulaire = new f_formulaire();
	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);
    $m_admin = new m_admin($base_de_donnee);
    $c_utilisateur = new c_utilisateur($m_admin);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);

	if($_SESSION['id'] != 1) header('Location: accueil'); // Si l'id est différent de 1 : alors ce n'est pas l'admin

	// On récupère les informations
	$p_admin = $m_admin->obtenir_information_admin($_SESSION['id']);
	$codeRetour = -1;
	$bienModifier = false;

	// Mise à jour de la biographie
	if(isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['age']) && isset($_POST['description']) && isset($_POST['exercicesPreferes']) && isset($_POST['poids']) && isset($_POST['taille']) && isset($_POST['mensuration'])){
		// On stocke les données dans les var
		$id = $p_admin->id;
		$nom = $_POST['nom'];
		$prenom = $_POST['prenom'];
		$age = $_POST['age'];
		$description = $_POST['description'];
		$exercicesPreferes = $_POST['exercicesPreferes'];
		$poids = $_POST['poids'];
		$taille = $_POST['taille'];
		$mensuration = $_POST['mensuration'];

		// Mise à jour de la photo
		$nomFichier = md5(uniqid());
		$target = PHOTO_BIOGRAPHIE_PATH;

		$codeRetour = $f_formulaire->uploadPicture($_FILES, $target, $nomFichier);
		
		if($codeRetour == 17){
			$nomFichier = $nomFichier .'.'.strtolower(substr(strrchr($_FILES['fichier']['name'], '.'),1));; // on récupère l'extension
			$m_admin->mise_a_jour_biographie($id, $nom, $prenom, $description, $exercicesPreferes, $poids, $taille, $mensuration, $age, $nomFichier);
		}else{
			$m_admin->mise_a_jour_biographie($id, $nom, $prenom, $description, $exercicesPreferes, $poids, $taille, $mensuration, $age, null);
		}

		if($m_admin){
			$bienModifier = true;
		}
	}

?>