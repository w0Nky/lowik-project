<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
	require_once('class/c_session.php');
	require_once('class/t_texte.php');
	require_once('class/c_utilisateur.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_articles.php');
	require_once('modele/m_admin.php');
	require_once('modele/m_slider.php');

	/**** OBJETS ****/
	$t_texte = new t_texte();
	
	$m_session = new m_session($base_de_donnee);
	$m_articles = new m_articles($base_de_donnee);
	$m_admin = new m_admin($base_de_donnee);
	$m_slider = new m_slider($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);
	$c_utilisateur = new c_utilisateur($m_admin);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);
	$m_session->compter_visite($_SERVER['REMOTE_ADDR'], date('Y-m-d')); // Sous forme AAAA-mm-dd

	$lastArticles = $m_articles->getThreeLastArticles();
	$informationBio = $m_admin->obtenir_information_admin(1);

	/* SLIDERS */
	// on compte le nbr de sliders
	$nbrActif = $m_slider->count_active_slider();
	// On récupère les sliders actifs
	$liste_sliders_actifs = $m_slider->liste_sliders_actifs();
?>