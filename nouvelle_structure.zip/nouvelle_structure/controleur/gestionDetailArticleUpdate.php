<?php
	/**** SESSION ****/
	session_start();

	/**** CLASS CONTROLEUR ****/
    require_once('class/t_texte.php');
    require_once('class/f_formulaire.php');

	require_once('class/c_session.php');

	/**** MODELE ****/
	require_once('modele/m_session.php');
	require_once('modele/m_admin.php');
	require_once('modele/m_articles.php');
	
	/**** OBJETS ****/
    $t_texte = new t_texte();
    $f_formulaire = new f_formulaire();

	$m_session = new m_session($base_de_donnee);
	$c_session = new c_session($m_session, $t_texte);

    $m_admin = new m_admin($base_de_donnee);
    $m_articles = new m_articles($base_de_donnee);

	/**** VERIF SESSION ****/
	$c_session->session();
	$c_session->calcul_nb_utilisateurs_connectes($_SERVER['REMOTE_ADDR']);

	if($_SESSION['id'] != 1) header('Location: accueil'); // Si l'id est différent de 1 : alors ce n'est pas l'admin

	$bienModifie = false;

	/** On liste les articles */
	if(!empty($url_param[0])) {
		if(preg_match('#^[0-9]{1,}$#', $url_param[0])) {
			$idArticle = $url_param[0];
		} else { $idArticle = -1; }
	} else { $idArticle = -1; }
    
    if(isset($_POST['titre']) && isset($_POST['description']) && isset($_POST['texte']) && isset($_POST['lienVignette'])){
		if($idArticle != -1){
			$titre = $f_formulaire->testInputData($_POST['titre']);

			/*if($f_formulaire->verify_url($_POST['lienVignette']) == 0){
				$url = $_POST['lienVignette'];
			}else{
				exit;
			}*/
			$url = $_POST['lienVignette'];

			//TODO : bbcode description et texte
			$description = $t_texte->convertBBcodeToHtml($_POST['description']);
			$texte = $t_texte->convertBBcodeToHtml($_POST['texte']);
			$id = $idArticle;
		
			/* On récupère les données en session */
			$auteur = $_SESSION['nom'] . ' ' . $_SESSION['prenom'];
			$datePublication = time();

			//Appel de la fonction ajouter article
			$m_articles->update_articles($id, $titre, $texte, $description, $url, $datePublication, $auteur);

			if($m_articles){
				$bienModifie = true;
			}
		}else{
			header('Location: dashboard');
		}
	}
?>